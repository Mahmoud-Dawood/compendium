/**
 * Pixel2HTML - /
 */

var msg = 'Pixel2HTML - /';

function printLog(log){
    'use strict';
  return console && console.log(log);
}

printLog(msg);


